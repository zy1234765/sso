package com.ithuang.index;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IndexApplicationTests {

    @Test
    void contextLoads() {
    }

}
