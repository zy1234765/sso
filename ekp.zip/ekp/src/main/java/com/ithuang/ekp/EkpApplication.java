package com.ithuang.ekp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EkpApplication {

    public static void main(String[] args) {
        SpringApplication.run(EkpApplication.class, args);
    }

}
