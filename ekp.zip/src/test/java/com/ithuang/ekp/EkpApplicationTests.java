package com.ithuang.ekp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EkpApplicationTests {

    @Test
    void contextLoads() {
    }

}
